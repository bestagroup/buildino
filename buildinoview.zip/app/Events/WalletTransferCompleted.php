<?php

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class WalletTransferCompleted
{
    use Dispatchable, SerializesModels;

    public function __construct(
        public readonly int $walletTransferId
    ) {
    }
}
