<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CancelFacilityReservationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'reason' => ['nullable', 'string', 'max:5000'],
        ];
    }
}
