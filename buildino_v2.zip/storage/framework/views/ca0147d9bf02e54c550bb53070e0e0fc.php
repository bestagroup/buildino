<?php $__env->startSection('title', 'مرکز عملیات Buildino'); ?>
<?php $__env->startSection('page-title', 'عملیات و فرم‌های سامانه'); ?>
<?php $__env->startSection('page-subtitle', 'ثبت، ویرایش و اجرای فرآیندهای عملیاتی روی Backend واقعی'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/buildino-crud.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="crud-hero">
    <div>
        <span class="eyebrow">Operational Web UI</span>
        <h2>مرکز عملیات Buildino</h2>
        <p>
            از این بخش می‌توانید اطلاعات پایه و فرآیندهای عملیاتی سامانه را
            بدون نیاز به Postman مستقیماً از طریق فرم‌های وب مدیریت کنید.
        </p>

        <div class="crud-access-badge">
            <?php echo $__env->make(
                'management.partials.icon',
                [
                    'name' => 'shield',
                    'size' => 15,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>
                <?php echo e($managementUi['access_label']
                    ?? 'دسترسی مدیریتی'); ?>

            </span>
        </div>
    </div>

    <div class="crud-hero__stats">
        <div>
            <strong><?php echo e(number_format($resourceCount)); ?></strong>
            <span>صفحه عملیاتی</span>
        </div>
        <div>
            <strong><?php echo e(number_format($groups->count())); ?></strong>
            <span>حوزه مدیریتی</span>
        </div>
    </div>
</section>

<div class="crud-groups">
    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="crud-group">
            <div class="crud-group__heading">
                <div class="crud-group__icon">
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => $group['icon'] ?? 'tools',
                            'size' => 22,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <div>
                    <h3><?php echo e($group['title']); ?></h3>
                    <p><?php echo e($group['description'] ?? ''); ?></p>
                </div>
            </div>

            <div class="crud-resource-grid">
                <?php $__currentLoopData = $group['resources']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a
                        class="crud-resource-card"
                        href="<?php echo e(route(
                                'management.operations.show',
                                $resource['key']
                            )); ?>"
                    >
                        <div>
                            <strong>
                                <?php echo e($resource['title']); ?>

                            </strong>

                            <p>
                                <?php echo e($resource['description'] ?? ''); ?>

                            </p>
                        </div>

                        <span class="crud-resource-card__arrow">
                            ←
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('management.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/management/operations/index.blade.php ENDPATH**/ ?>