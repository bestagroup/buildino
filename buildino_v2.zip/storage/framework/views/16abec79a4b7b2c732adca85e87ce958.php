<!doctype html>
<html lang="fa" dir="rtl" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >
    <meta
        name="csrf-token"
        content="<?php echo e(csrf_token()); ?>"
    >
    <meta
        name="robots"
        content="noindex,nofollow"
    >
    <meta
        name="color-scheme"
        content="light dark"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'پرتال Buildino'); ?>
    </title>

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-fonts.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.bootstrap.css')); ?>"
        integrity="<?php echo e(config('management_ui.libraries.bootstrap.css_integrity')); ?>"
        crossorigin="anonymous"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.sweetalert2.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.datatables.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.datatables.responsive_css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-datatables.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-portal.css')); ?>"
    >

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<?php
    $portalUser =
        auth('web')->user()
        ?? request()->user();

    $header =
        $portalData['header']
        ?? [];

    $wallet =
        $header['wallet']
        ?? [];

    $notifications =
        $header['notifications']
        ?? [];

    $notificationItems =
        $notifications['items']
        ?? [];

    $unreadCount =
        (int) (
            $notifications[
                'unread_count'
            ]
            ?? 0
        );

    $activeArea =
        $portalData['area']
        ?? 'resident';

    /*
    |--------------------------------------------------------------------------
    | Portal JavaScript Bootstrap Values
    |--------------------------------------------------------------------------
    |
    | Keep Blade @json directives simple. Complex nested expressions inside
    | multiline @json(...) directives can be compiled incorrectly by Blade.
    |
    */

    $portalCsrfToken =
        csrf_token();

    $portalNotificationReadUrl =
        url(
            '/api/v1/notifications'
        );

    $portalNotificationReadAllUrl =
        url(
            '/api/v1/notifications/read-all'
        );

    $portalDefaultGateway =
        data_get(
            $portalData,
            'payment_gateway.default',
            config(
                'payment_gateways.default',
                'generic'
            )
        );

    $portalGatewayEnabled =
        (bool) data_get(
            $portalData,
            'payment_gateway.enabled',
            false
        );
?>

<body
    class="portal-body"
    data-portal-user-id="<?php echo e($portalUser?->getKey()); ?>"
>
<div class="portal-shell">
    <aside
        class="portal-sidebar"
        id="portalSidebar"
    >
        <a
            href="<?php echo e(route('portal.dashboard')); ?>"
            class="portal-brand"
        >
            <span class="portal-brand__mark">
                B
            </span>

            <span class="portal-brand__copy">
                <strong>Buildino</strong>
                <small>
                    پرتال کاربران
                </small>
            </span>
        </a>

        <div class="portal-user-card">
            <div class="portal-avatar">
                <?php echo e(mb_substr(
                        $portalUser->first_name
                        ?: $portalUser->last_name
                        ?: 'U',
                        0,
                        1
                    )); ?>

            </div>

            <div>
                <strong>
                    <?php echo e(trim(
                            ($portalUser->first_name ?? '')
                            . ' '
                            . ($portalUser->last_name ?? '')
                        )
                        ?: $portalUser->mobile); ?>

                </strong>

                <span>
                    <?php if($activeArea === 'provider'): ?>
                        ارائه‌دهنده خدمات
                    <?php else: ?>
                        مالک / ساکن
                    <?php endif; ?>
                </span>
            </div>
        </div>

        <nav class="portal-nav">
            <?php if($portalAreas['resident'] ?? false): ?>
                <a
                    href="<?php echo e(route('portal.resident.dashboard')); ?>"
                    class="<?php echo e($activeArea === 'resident'
                            ? 'is-active'
                            : ''); ?>"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'home',
                            'size' => 19,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <span>
                        خانه من
                    </span>
                </a>
            <?php endif; ?>

            <?php if($portalAreas['provider'] ?? false): ?>
                <a
                    href="<?php echo e(route('portal.provider.dashboard')); ?>"
                    class="<?php echo e($activeArea === 'provider'
                            ? 'is-active'
                            : ''); ?>"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'tools',
                            'size' => 19,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <span>
                        پنل ارائه‌دهنده
                    </span>
                </a>
            <?php endif; ?>

            <?php echo $__env->yieldContent('sidebar-links'); ?>
        </nav>

        <div class="portal-sidebar__footer">
            <div class="portal-sidebar__security">
                <?php echo $__env->make(
                    'management.partials.icon',
                    [
                        'name' => 'shield',
                        'size' => 16,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <span>
                    دسترسی امن و محدود به اطلاعات حساب شما
                </span>
            </div>

            <form
                method="POST"
                action="<?php echo e(route('portal.logout')); ?>"
            >
                <?php echo csrf_field(); ?>

                <button
                    type="submit"
                    class="portal-logout"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'logout',
                            'size' => 17,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    خروج از حساب
                </button>
            </form>
        </div>
    </aside>

    <button
        type="button"
        class="portal-sidebar-backdrop"
        id="portalSidebarBackdrop"
        aria-label="بستن منو"
    ></button>

    <main class="portal-main">
        <header class="portal-topbar">
            <div class="portal-topbar__title">
                <button
                    type="button"
                    class="portal-icon-button portal-mobile-menu"
                    id="portalSidebarToggle"
                    aria-label="نمایش منو"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'menu',
                            'size' => 20,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>

                <div>
                    <span>
                        BUILDINO PORTAL
                    </span>

                    <h1>
                        <?php echo $__env->yieldContent(
                            'page-title',
                            'پرتال کاربری'
                        ); ?>
                    </h1>
                </div>
            </div>

            <div class="portal-topbar__actions">
                <div class="portal-wallet-chip">
                    <span class="portal-wallet-chip__icon">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'wallet',
                                'size' => 18,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </span>

                    <div>
                        <small>
                            موجودی شخصی
                        </small>

                        <strong>
                            <?php echo e(number_format(
                                    (int) (
                                        $wallet[
                                            'available_balance'
                                        ]
                                        ?? 0
                                    )
                                )); ?>

                            <em>
                                <?php echo e($wallet['currency']
                                    ?? 'IRR'); ?>

                            </em>
                        </strong>
                    </div>
                </div>

                <div class="dropdown">
                    <button
                        type="button"
                        class="portal-icon-button portal-notification-button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                        title="اعلان‌ها"
                    >
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'bell',
                                'size' => 19,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php if($unreadCount > 0): ?>
                            <span class="portal-notification-badge">
                                <?php echo e($unreadCount > 99
                                        ? '99+'
                                        : $unreadCount); ?>

                            </span>
                        <?php endif; ?>
                    </button>

                    <div class="dropdown-menu portal-notification-menu">
                        <div class="portal-notification-menu__header">
                            <div>
                                <strong>
                                    اعلان‌ها
                                </strong>
                                <span>
                                    <?php echo e(number_format($unreadCount)); ?>

                                    خوانده‌نشده
                                </span>
                            </div>

                            <?php if($unreadCount > 0): ?>
                                <button
                                    type="button"
                                    data-portal-read-all
                                >
                                    خواندن همه
                                </button>
                            <?php endif; ?>
                        </div>

                        <div class="portal-notification-list">
                            <?php $__empty_1 = true; $__currentLoopData = $notificationItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <button
                                    type="button"
                                    class="portal-notification-item <?php echo e(! ($notification['is_read'] ?? false)
                                            ? 'is-unread'
                                            : ''); ?>"
                                    data-notification-id="<?php echo e($notification['id']); ?>"
                                    <?php if(! empty($notification['href'])): ?>
                                        data-notification-href="<?php echo e($notification['href']); ?>"
                                    <?php endif; ?>
                                >
                                    <span class="portal-notification-item__dot"></span>

                                    <span>
                                        <strong>
                                            <?php echo e($notification['title']
                                                ?: 'اعلان Buildino'); ?>

                                        </strong>

                                        <small>
                                            <?php echo e(\Illuminate\Support\Str::limit(
                                                    $notification['message']
                                                    ?? '',
                                                    90
                                                )); ?>

                                        </small>

                                        <em>
                                            <?php echo e($notification[
                                                    'created_at_jalali'
                                                ]
                                                ?? '—'); ?>

                                        </em>
                                    </span>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="portal-empty-mini">
                                    اعلان جدیدی ندارید.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <button
                    type="button"
                    class="portal-icon-button"
                    id="portalThemeToggle"
                    title="تغییر پوسته"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'moon',
                            'size' => 18,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>
            </div>
        </header>

        <div class="portal-content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>

<script>
    window.BuildinoPortal = {
        csrfToken: <?php echo json_encode($portalCsrfToken, 15, 512) ?>,
        area: <?php echo json_encode($activeArea, 15, 512) ?>,
        notificationReadUrl: <?php echo json_encode($portalNotificationReadUrl, 15, 512) ?>,
        notificationReadAllUrl: <?php echo json_encode($portalNotificationReadAllUrl, 15, 512) ?>,
        defaultGateway: <?php echo json_encode($portalDefaultGateway, 15, 512) ?>,
        gatewayEnabled: <?php echo json_encode($portalGatewayEnabled, 15, 512) ?>
    };
</script>

<script
    src="<?php echo e(config('management_ui.libraries.bootstrap.js')); ?>"
    integrity="<?php echo e(config('management_ui.libraries.bootstrap.js_integrity')); ?>"
    crossorigin="anonymous"
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.bootstrap5_js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.responsive_js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.responsive_bootstrap5_js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.sweetalert2.js')); ?>"
></script>

<script
    src="<?php echo e(config('management_ui.libraries.jdate.js')); ?>"
></script>

<script
    src="<?php echo e(asset('js/buildino-datatables.js')); ?>"
    defer
></script>

<script
    src="<?php echo e(asset('js/buildino-portal.js')); ?>"
    defer
></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/portal/layouts/app.blade.php ENDPATH**/ ?>