<?php
    $tableId =
        $id
        ?? (
            'datatable-'
            . \Illuminate\Support\Str::random(8)
        );

    $encodedColumns =
        base64_encode(
            json_encode(
                $columns ?? [],
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            )
        );
?>

<div
    class="buildino-dt-shell"
    data-dt-shell
>
    <div class="buildino-dt-loading" data-dt-loading>
        <span class="spinner-border spinner-border-sm"></span>
        <span>در حال دریافت اطلاعات...</span>
    </div>

    <div class="table-responsive">
        <table
            id="<?php echo e($tableId); ?>"
            class="table align-middle buildino-datatable js-server-datatable"
            data-dt-url="<?php echo e($url); ?>"
            data-dt-columns="<?php echo e($encodedColumns); ?>"
            data-dt-page-length="<?php echo e($pageLength ?? 10); ?>"
            <?php if(! empty($countTarget)): ?>
                data-dt-count-target="<?php echo e($countTarget); ?>"
            <?php endif; ?>
        >
            <thead>
            <tr>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th>
                        <?php echo e($column['title'] ?? $column['data']); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/shared/server-datatable.blade.php ENDPATH**/ ?>