<!doctype html>
<html lang="fa" dir="rtl" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex,nofollow">
    <meta name="color-scheme" content="light">

    <title>ورود به پنل مدیریتی Buildino</title>

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-fonts.css')); ?>"
    >
    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-management.css')); ?>"
    >
</head>

<body class="login-page">
<div class="login-shell">
    <section class="login-visual">
        <div class="login-visual__mesh"></div>

        <div class="login-visual__content">
            <div class="showcase-brand">
                <div class="brand-mark brand-mark--large">
                    <span>B</span>
                </div>

                <div>
                    <strong>Buildino</strong>
                    <span>Smart Building Management</span>
                </div>
            </div>

            <div class="login-visual__headline">
                <span class="eyebrow eyebrow--light">
                    مدیریت هوشمند، تصمیم‌گیری دقیق
                </span>

                <h1>
                    همه‌چیز برای مدیریت ساختمان،
                    <em>در یک مرکز واحد.</em>
                </h1>

                <p>
                    از ساختار مجتمع و ساکنین تا کیف پول، شارژ،
                    رزرو امکانات، خدمات، پشتیبانی و گزارش‌های مدیریتی.
                </p>
            </div>

            <div class="login-feature-grid">
                <article>
                    <div class="login-feature-icon">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            ['name' => 'building']
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <strong>ساختار یکپارچه</strong>
                    <span>مجتمع، ساختمان، واحد و ساکنین</span>
                </article>

                <article>
                    <div class="login-feature-icon">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            ['name' => 'wallet']
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <strong>شفافیت مالی</strong>
                    <span>Wallet، Invoice، Payment و Ledger</span>
                </article>

                <article>
                    <div class="login-feature-icon">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            ['name' => 'shield']
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <strong>دسترسی کنترل‌شده</strong>
                    <span>Role، Permission و Scope واقعی</span>
                </article>
            </div>
        </div>

        <div class="login-visual__footer">
            <span>Buildino Backend/API v1.0</span>
            <span>Secure • Scoped • Auditable</span>
        </div>
    </section>

    <main class="login-form-area">
        <div class="login-card">
            <div class="login-card__mobile-brand">
                <div class="brand-mark">
                    <span>B</span>
                </div>
                <strong>Buildino</strong>
            </div>

            <div class="login-card__header">
                <span class="eyebrow">
                    پنل مدیریتی
                </span>

                <h2>خوش آمدید</h2>

                <p>
                    برای ورود، شماره موبایل یا ایمیل و رمز عبور خود را وارد کنید.
                </p>
            </div>

            <?php if(session('status')): ?>
                <div class="alert alert--success login-alert">
                    <strong>انجام شد</strong>
                    <span><?php echo e(session('status')); ?></span>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert--danger login-alert">
                    <strong>ورود انجام نشد</strong>

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($error); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <form
                method="POST"
                action="<?php echo e(route('management.login.store')); ?>"
                class="login-form"
            >
                <?php echo csrf_field(); ?>

                <label class="auth-field">
                    <span>شماره موبایل یا ایمیل</span>

                    <div class="auth-input">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'user',
                                'size' => 18,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <input
                            type="text"
                            name="login"
                            value="<?php echo e(old('login')); ?>"
                            autocomplete="username"
                            placeholder="0912... یا name@example.com"
                            dir="ltr"
                            required
                            autofocus
                        >
                    </div>
                </label>

                <label class="auth-field">
                    <span>رمز عبور</span>

                    <div class="auth-input">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'lock',
                                'size' => 18,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <input
                            type="password"
                            name="password"
                            autocomplete="current-password"
                            placeholder="رمز عبور"
                            dir="ltr"
                            required
                        >
                    </div>
                </label>

                <div class="login-form__meta">
                    <label class="remember-row">
                        <input
                            type="hidden"
                            name="remember"
                            value="0"
                        >

                        <input
                            type="checkbox"
                            name="remember"
                            value="1"
                            <?php if(old('remember')): echo 'checked'; endif; ?>
                        >

                        <span>
                            مرا در این دستگاه به خاطر بسپار
                        </span>
                    </label>

                    <a
                        class="forgot-password-link"
                        href="<?php echo e(route('password.request')); ?>"
                    >
                        رمز عبور را فراموش کرده‌اید؟
                    </a>
                </div>

                <button
                    class="login-submit"
                    type="submit"
                >
                    <span>ورود به داشبورد</span>

                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'arrow-left',
                            'size' => 18,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>
            </form>

            <div class="login-security-note">
                <?php echo $__env->make(
                    'management.partials.icon',
                    [
                        'name' => 'shield',
                        'size' => 16,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <span>
                    محتوای پنل بر اساس نقش و محدوده دسترسی حساب شما نمایش داده می‌شود.
                </span>
            </div>
        </div>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/management/auth/login.blade.php ENDPATH**/ ?>