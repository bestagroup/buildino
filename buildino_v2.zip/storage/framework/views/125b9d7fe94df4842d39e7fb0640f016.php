<?php $__env->startSection(
    'title',
    ($detail['title'] ?? 'جزئیات')
    . ' | Buildino'
); ?>

<?php $__env->startSection(
    'page-title',
    'جزئیات '
    . (
        $operationConfig['title']
        ?? ''
    )
); ?>

<?php $__env->startSection('sidebar-links'); ?>
    <?php
        $resources =
            config(
                "portal_operations.{$area}",
                []
            );
    ?>

    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a
            href="<?php echo e(route(
                    "portal.{$area}.operations.index",
                    [
                        'resource' => $key,
                    ]
                )); ?>"
            class="<?php echo e($resource === $key
                    ? 'is-active'
                    : ''); ?>"
        >
            <?php echo $__env->make(
                'management.partials.icon',
                [
                    'name' =>
                        $item['icon']
                        ?? 'grid',
                    'size' => 18,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>
                <?php echo e($item['title']); ?>

            </span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav class="portal-breadcrumb">
    <a
        href="<?php echo e(route(
                "portal.{$area}.dashboard"
            )); ?>"
    >
        داشبورد
    </a>

    <span>/</span>

    <a
        href="<?php echo e(route(
                "portal.{$area}.operations.index",
                [
                    'resource' =>
                        $resource,
                ]
            )); ?>"
    >
        <?php echo e($operationConfig['title']
            ?? 'عملیات'); ?>

    </a>

    <span>/</span>
    <strong>جزئیات</strong>
</nav>

<section class="portal-detail-hero">
    <div>
        <span class="portal-eyebrow">
            OPERATION DETAIL
        </span>

        <h2>
            <?php echo e($detail['title']); ?>

        </h2>

        <p>
            <?php echo e($detail['subtitle']
                ?? ''); ?>

        </p>
    </div>

    <span class="portal-status portal-status--<?php echo e($detail['status_tone']
        ?? 'info'); ?>">
        <?php echo e($detail['status']
            ?? '—'); ?>

    </span>
</section>

<section class="portal-detail-facts">
    <?php $__currentLoopData = $detail['facts']
        ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article>
            <span>
                <?php echo e($label); ?>

            </span>

            <strong>
                <?php echo e($value); ?>

            </strong>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__currentLoopData = $detail['sections']
    ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="portal-section">
        <div class="portal-section__heading">
            <div>
                <span class="portal-eyebrow">
                    DETAIL
                </span>
                <h3>
                    <?php echo e($section['title']); ?>

                </h3>
            </div>
        </div>

        <?php if(
            ($section['type'] ?? '')
            === 'table'
        ): ?>
            <div class="portal-table-card">
                <div class="table-responsive">
                    <table class="table portal-table align-middle">
                        <thead>
                        <tr>
                            <?php $__currentLoopData = $section['columns']
                                ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>
                                    <?php echo e($column); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $section['rows']
                            ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php echo e($cell); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td
                                    colspan="<?php echo e(count(
                                            $section['columns']
                                            ?? []
                                        )); ?>"
                                    class="portal-table-empty"
                                >
                                    رکوردی وجود ندارد.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php elseif(
            ($section['type'] ?? '')
            === 'timeline'
        ): ?>
            <div class="portal-detail-timeline">
                <?php $__empty_1 = true; $__currentLoopData = $section['rows']
                    ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article>
                        <span class="portal-detail-timeline__dot"></span>

                        <div>
                            <strong>
                                <?php echo e($row['title']
                                    ?? 'رویداد'); ?>

                            </strong>

                            <p>
                                <?php echo e($row['meta']
                                    ?? ''); ?>

                            </p>

                            <time>
                                <?php echo e($row['time']
                                    ?? '—'); ?>

                            </time>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="portal-empty-state">
                        رویدادی ثبت نشده است.
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('portal.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/portal/operations/show.blade.php ENDPATH**/ ?>