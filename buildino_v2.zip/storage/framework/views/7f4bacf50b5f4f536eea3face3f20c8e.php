<?php $__env->startSection('title', $resource['title'] . ' | Buildino'); ?>
<?php $__env->startSection('page-title', $resource['title']); ?>
<?php $__env->startSection('page-subtitle', $resource['description'] ?? 'مدیریت اطلاعات سامانه'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/buildino-crud.css')); ?>">
<?php $__env->stopPush(); ?>

<?php
    $visibleResourceKeys =
        $managementUi['visible_resources']
        ?? [];

    $siblingResources =
        collect(
            config(
                'management_crud.resources',
                []
            )
        )
            ->filter(
                fn (
                    array $item,
                    string $key
                ): bool =>
                    ($item['group'] ?? null)
                        === ($resource['group'] ?? null)
                    && in_array(
                        $key,
                        $visibleResourceKeys,
                        true
                    )
            );
?>

<?php $__env->startSection('content'); ?>
<div
    class="crud-page"
    id="buildinoCrudApp"
    data-resource="<?php echo e($resourceKey); ?>"
>
    <div class="crud-breadcrumb">
        <a href="<?php echo e(route('management.dashboard')); ?>">
            داشبورد
        </a>
        <span>/</span>
        <a href="<?php echo e(route('management.operations.index')); ?>">
            عملیات
        </a>
        <span>/</span>
        <strong><?php echo e($resource['title']); ?></strong>
    </div>

    <section class="crud-header">
        <div class="crud-header__copy">
            <span class="eyebrow">
                <?php echo e($groups[$resource['group']]['title'] ?? 'Operations'); ?>

            </span>
            <h2><?php echo e($resource['title']); ?></h2>
            <p>
                <?php echo e($resource['description'] ?? ''); ?>

            </p>

            <?php if(! empty($resource['note'])): ?>
                <div class="crud-inline-note">
                    <?php echo e($resource['note']); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="crud-header__actions">
            <a
                href="<?php echo e(route('management.operations.index')); ?>"
                class="crud-button crud-button--soft"
            >
                همه ماژول‌ها
            </a>

            <?php if(! empty($resource['create'])): ?>
                <button
                    type="button"
                    class="crud-button crud-button--primary"
                    id="crudCreateButton"
                >
                    + ثبت رکورد جدید
                </button>
            <?php endif; ?>
        </div>
    </section>

    <?php if($siblingResources->count() > 1): ?>
        <nav
            class="crud-sibling-nav"
            aria-label="زیرماژول‌های مرتبط"
        >
            <?php $__currentLoopData = $siblingResources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    href="<?php echo e(route(
                            'management.operations.show',
                            $key
                        )); ?>"
                    class="<?php echo e($key === $resourceKey
                            ? 'is-active'
                            : ''); ?>"
                >
                    <?php echo e($item['title']); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    <?php endif; ?>

    <?php if(! empty($resource['context'])): ?>
        <section class="crud-context-card">
            <div class="crud-context-card__heading">
                <strong>محدوده عملیات</strong>
                <span>
                    برای بارگذاری داده‌ها، مقادیر لازم را انتخاب کنید.
                </span>
            </div>

            <div
                class="crud-context-grid"
                id="crudContextFields"
            >
                <?php $__currentLoopData = $resource['context']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $context): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="crud-field">
                        <span>
                            <?php echo e($context['label']); ?>

                            <?php if($context['required'] ?? false): ?>
                                <b>*</b>
                            <?php endif; ?>
                        </span>

                        <select
                            data-context-name="<?php echo e($context['name']); ?>"
                            data-lookup="<?php echo e($context['lookup']); ?>"
                            data-required="<?php echo e(($context['required'] ?? false) ? '1' : '0'); ?>"
                            <?php if(! empty($context['depends_on'])): ?>
                                data-depends-on="<?php echo e($context['depends_on']); ?>"
                            <?php endif; ?>
                        >
                            <option value="">
                                انتخاب کنید
                            </option>
                        </select>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if(($resource['mode'] ?? 'table') === 'singleton'): ?>
        <section class="crud-panel crud-singleton-panel">
            <div class="crud-panel__header">
                <div>
                    <h3>تنظیمات</h3>
                    <p>
                        مقدار فعلی را بارگذاری، ویرایش و ذخیره کنید.
                    </p>
                </div>

                <button
                    type="button"
                    class="crud-button crud-button--soft"
                    id="crudLoadSingleton"
                >
                    بارگذاری
                </button>
            </div>

            <form
                class="crud-form crud-form--inline"
                id="crudSingletonForm"
                autocomplete="off"
            >
                <div
                    class="crud-form-grid"
                    id="crudSingletonFields"
                ></div>

                <div class="crud-form-actions">
                    <button
                        type="submit"
                        class="crud-button crud-button--primary"
                    >
                        ذخیره تنظیمات
                    </button>
                </div>
            </form>
        </section>
    <?php else: ?>
        <section class="crud-panel">
            <div class="crud-toolbar">
                <div class="crud-search">
                    <input
                        type="search"
                        id="crudSearch"
                        placeholder="جستجو در رکوردهای بارگذاری‌شده..."
                    >
                </div>

                <div class="crud-toolbar__actions">
                    <select id="crudPageSize">
                        <option value="10">۱۰ رکورد</option>
                        <option value="25" selected>۲۵ رکورد</option>
                        <option value="50">۵۰ رکورد</option>
                        <option value="100">۱۰۰ رکورد</option>
                    </select>

                    <button
                        type="button"
                        class="crud-button crud-button--soft"
                        id="crudRefreshButton"
                    >
                        بروزرسانی
                    </button>
                </div>
            </div>

            <div
                class="crud-state"
                id="crudState"
            >
                <div class="crud-state__loader"></div>
                <span>در حال بارگذاری...</span>
            </div>

            <div
                class="crud-table-wrap"
                id="crudTableWrap"
                hidden
            >
                <table class="crud-table">
                    <thead>
                        <tr id="crudTableHead"></tr>
                    </thead>
                    <tbody id="crudTableBody"></tbody>
                </table>
            </div>

            <div
                class="crud-pagination"
                id="crudPagination"
                hidden
            >
                <span id="crudRecordSummary"></span>

                <div>
                    <button
                        type="button"
                        id="crudPrevPage"
                        class="crud-page-button"
                    >
                        قبلی
                    </button>
                    <strong id="crudCurrentPage">1</strong>
                    <button
                        type="button"
                        id="crudNextPage"
                        class="crud-page-button"
                    >
                        بعدی
                    </button>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <div
        class="crud-drawer-backdrop"
        id="crudDrawerBackdrop"
    ></div>

    <aside
        class="crud-drawer"
        id="crudDrawer"
        aria-hidden="true"
    >
        <div class="crud-drawer__header">
            <div>
                <span class="eyebrow" id="crudDrawerEyebrow">
                    Create
                </span>
                <h3 id="crudDrawerTitle">
                    ثبت رکورد
                </h3>
            </div>

            <button
                type="button"
                class="crud-close-button"
                id="crudDrawerClose"
                aria-label="بستن"
            >
                ×
            </button>
        </div>

        <form
            id="crudForm"
            class="crud-form"
            autocomplete="off"
        >
            <input
                type="hidden"
                id="crudRecordId"
            >

            <div
                class="crud-form-grid"
                id="crudFormFields"
            ></div>

            <div class="crud-form-error" id="crudFormError"></div>

            <div class="crud-form-actions">
                <button
                    type="button"
                    class="crud-button crud-button--soft"
                    id="crudCancelButton"
                >
                    انصراف
                </button>

                <button
                    type="submit"
                    class="crud-button crud-button--primary"
                    id="crudSaveButton"
                >
                    ذخیره
                </button>
            </div>
        </form>
    </aside>

    <div
        class="crud-modal-backdrop"
        id="crudActionBackdrop"
    ></div>

    <div
        class="crud-modal"
        id="crudActionModal"
        aria-hidden="true"
    >
        <div class="crud-modal__header">
            <div>
                <span class="eyebrow">
                    Workflow Action
                </span>
                <h3 id="crudActionTitle">
                    عملیات
                </h3>
            </div>

            <button
                type="button"
                class="crud-close-button"
                id="crudActionClose"
            >
                ×
            </button>
        </div>

        <form id="crudActionForm">
            <div
                class="crud-form-grid"
                id="crudActionFields"
            ></div>

            <div
                class="crud-form-error"
                id="crudActionError"
            ></div>

            <div class="crud-form-actions">
                <button
                    type="button"
                    class="crud-button crud-button--soft"
                    id="crudActionCancel"
                >
                    انصراف
                </button>

                <button
                    type="submit"
                    class="crud-button crud-button--primary"
                    id="crudActionSubmit"
                >
                    اجرا
                </button>
            </div>
        </form>
    </div>

    <div
        class="crud-toast-stack"
        id="crudToastStack"
        aria-live="polite"
    ></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    window.BuildinoCrud = {
        resourceKey: <?php echo json_encode($resourceKey, 15, 512) ?>,
        resource: <?php echo e(\Illuminate\Support\Js::from($resource)); ?>,
        lookupBase: <?php echo json_encode(url('/management/lookups'), 15, 512) ?>,
        csrfToken: <?php echo json_encode(csrf_token(), 15, 512) ?>
    };
</script>
<script
    src="<?php echo e(asset('js/buildino-crud.js')); ?>"
    defer
></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('management.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/management/operations/resource.blade.php ENDPATH**/ ?>