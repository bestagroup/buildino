<?php $__env->startSection(
    'title',
    ($operationConfig['title'] ?? 'عملیات')
    . ' | Buildino'
); ?>

<?php $__env->startSection(
    'page-title',
    $operationConfig['title']
    ?? 'عملیات'
); ?>

<?php $__env->startSection('sidebar-links'); ?>
    <?php
        $resources =
            config(
                "portal_operations.{$area}",
                []
            );
    ?>

    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a
            href="<?php echo e(route(
                    "portal.{$area}.operations.index",
                    [
                        'resource' => $key,
                    ]
                )); ?>"
            class="<?php echo e($resource === $key
                    ? 'is-active'
                    : ''); ?>"
        >
            <?php echo $__env->make(
                'management.partials.icon',
                [
                    'name' =>
                        $item['icon']
                        ?? 'grid',
                    'size' => 18,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <span>
                <?php echo e($item['title']); ?>

            </span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="portal-operation-hero">
    <div>
        <span class="portal-eyebrow">
            SERVER-SIDE DATATABLE
        </span>

        <h2>
            <?php echo e($operationConfig['title']
                ?? 'عملیات'); ?>

        </h2>

        <p>
            <?php echo e($operationConfig['description']
                ?? ''); ?>

        </p>
    </div>

    <a
        href="<?php echo e(route(
                "portal.{$area}.dashboard"
            )); ?>"
        class="portal-action-button"
    >
        بازگشت به داشبورد
    </a>
</section>

<section
    class="portal-section portal-datatable-section"
    data-dt-filter-scope
>
    <div class="portal-datatable-toolbar">
        <?php if(
            in_array(
                'status',
                $operationConfig['filters']
                ?? [],
                true
            )
        ): ?>
            <label>
                <span>وضعیت</span>

                <select
                    data-dt-filter="status"
                >
                    <option value="">
                        همه وضعیت‌ها
                    </option>
                    <option value="pending">در انتظار</option>
                    <option value="payment_pending">در انتظار پرداخت</option>
                    <option value="issued">صادر شده</option>
                    <option value="partial">پرداخت ناقص</option>
                    <option value="paid">پرداخت شده</option>
                    <option value="overdue">سررسید گذشته</option>
                    <option value="approved">تأیید شده</option>
                    <option value="confirmed">قطعی</option>
                    <option value="invited">دعوت شده</option>
                    <option value="entered">وارد شده</option>
                    <option value="exited">خارج شده</option>
                    <option value="open">باز</option>
                    <option value="assigned">تخصیص داده شده</option>
                    <option value="in_progress">در حال انجام</option>
                    <option value="awaiting_confirmation">در انتظار تأیید</option>
                    <option value="waiting_user">در انتظار کاربر</option>
                    <option value="resolved">حل شده</option>
                    <option value="closed">بسته شده</option>
                    <option value="cancelled">لغو شده</option>
                    <option value="rejected">رد شده</option>
                    <option value="settled">تسویه شده</option>
                    <option value="failed">ناموفق</option>
                </select>
            </label>
        <?php endif; ?>

        <?php if(
            in_array(
                'from',
                $operationConfig['filters']
                ?? [],
                true
            )
        ): ?>
            <label>
                <span>از تاریخ</span>
                <input
                    type="date"
                    data-dt-filter="from"
                >
            </label>
        <?php endif; ?>

        <?php if(
            in_array(
                'to',
                $operationConfig['filters']
                ?? [],
                true
            )
        ): ?>
            <label>
                <span>تا تاریخ</span>
                <input
                    type="date"
                    data-dt-filter="to"
                >
            </label>
        <?php endif; ?>

        <button
            type="button"
            class="portal-dt-reset"
            data-dt-reset
        >
            پاک‌کردن فیلتر
        </button>
    </div>

    <div class="portal-datatable-card">
        <?php echo $__env->make(
            'shared.server-datatable',
            [
                'id' =>
                    "{$area}-{$resource}-table",
                'url' =>
                    $dataUrl,
                'columns' =>
                    $operationConfig['columns']
                    ?? [],
                'pageLength' =>
                    15,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('portal.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/portal/operations/index.blade.php ENDPATH**/ ?>