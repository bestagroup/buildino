<?php $__env->startSection('title', 'داشبورد مدیریتی Buildino'); ?>

<?php $__env->startSection('page-title', $roleDashboard['profile']['short_title'] ?? 'داشبورد مدیریتی'); ?>

<?php $__env->startSection(
    'page-subtitle',
    ($roleDashboard['profile']['description'] ?? 'مدیریت و پایش سامانه Buildino')
); ?>

<?php
    $scope = $dashboard['scope'];
    $counts = $dashboard['counts'];
    $buildingDashboard = $dashboard['building_dashboard'];
    $platformSummary = $dashboard['platform_summary'];
    $currency = $scope['currency'] ?? 'IRR';
    $headerWallet =
        $managementHeader['wallet'] ?? [];
    $headerNotifications =
        $managementHeader['notifications'] ?? [];
    $currentRole =
        data_get(
            $managementUi ?? [],
            'primary_role.display_name',
            'کاربر سامانه'
        );
    $accessLabel =
        data_get(
            $managementUi ?? [],
            'access_label',
            'دسترسی فعال'
        );

    $roleProfile =
        $roleDashboard['profile'] ?? [];
    $roleSections =
        $roleDashboard['sections'] ?? [];
    $roleQuickActions =
        $roleDashboard['quick_actions'] ?? [];
    $roleModules =
        $roleDashboard['modules'] ?? [];
    $roleOperationKeys =
        $roleDashboard['operation_keys'] ?? [];
    $roleRecentKeys =
        $roleDashboard['recent_keys'] ?? [];

    $money = static fn ($value) =>
        number_format((int) ($value ?? 0));

    $personName = static function ($user): string {
        if (! $user) {
            return '—';
        }

        $name = trim(
            ($user->first_name ?? '')
            . ' '
            . ($user->last_name ?? '')
        );

        return $name !== ''
            ? $name
            : ($user->mobile ?? '—');
    };

    $statusLabels = [
        'pending' => 'در انتظار',
        'payment_pending' => 'در انتظار پرداخت',
        'approved' => 'تأییدشده',
        'rejected' => 'ردشده',
        'confirmed' => 'قطعی',
        'cancelled' => 'لغوشده',
        'completed' => 'تکمیل‌شده',
        'expired' => 'منقضی',
        'open' => 'باز',
        'assigned' => 'تخصیص‌یافته',
        'in_progress' => 'در حال انجام',
        'awaiting_confirmation' => 'منتظر تأیید',
        'waiting_user' => 'منتظر کاربر',
        'resolved' => 'حل‌شده',
        'closed' => 'بسته',
        'draft' => 'پیش‌نویس',
        'issued' => 'صادرشده',
        'partial' => 'پرداخت جزئی',
        'paid' => 'پرداخت‌شده',
        'overdue' => 'معوق',
        'void' => 'باطل',
        'failed' => 'ناموفق',
        'processing' => 'در حال پردازش',
        'refunded' => 'بازپرداخت',
        'partial_refund' => 'بازپرداخت جزئی',
    ];

    $statusClass = static function ($value): string {
        return match ($value) {
            'paid', 'completed', 'confirmed', 'resolved', 'closed', 'approved' =>
                'status-badge--success',
            'pending', 'payment_pending', 'open', 'assigned', 'processing',
            'waiting_user', 'awaiting_confirmation', 'partial' =>
                'status-badge--warning',
            'failed', 'rejected', 'overdue' =>
                'status-badge--danger',
            'cancelled', 'expired', 'void' =>
                'status-badge--muted',
            default =>
                'status-badge--info',
        };
    };


    $financialKpis = $buildingDashboard['kpis'] ?? [];

    $heroKpis =
        collect(
            $roleDashboard['kpis'] ?? []
        )
            ->map(
                static function (
                    array $item
                ) use ($money): array {
                    return [
                        ...$item,
                        'value' =>
                            ($item['money'] ?? false)
                                ? $money($item['value'] ?? 0)
                                : number_format(
                                    (int) (
                                        $item['value']
                                        ?? 0
                                    )
                                ),
                        'suffix' =>
                            $item['unit']
                            ?? '',
                    ];
                }
            )
            ->all();

    $aging = $buildingDashboard['receivables_aging'] ?? [];
    $agingMax = max(
        1,
        ...array_map(
            static fn ($value) => (int) $value,
            array_values($aging ?: [0])
        )
    );

    $healthStatus = $dashboard['health']['status'] ?? 'unknown';
?>

<?php $__env->startSection('content'); ?>
<section class="hero-panel" id="overview">
    <div class="hero-panel__copy">
        <span class="eyebrow">
            <?php echo e($roleProfile['eyebrow'] ?? 'MANAGEMENT WORKSPACE'); ?>

        </span>

        <h2>
            <?php echo e($roleProfile['title'] ?? 'داشبورد مدیریتی'); ?>


            <?php if($selectedBuilding): ?>
                <small class="hero-role-scope">
                    <?php echo e($selectedBuilding->title); ?>

                </small>
            <?php endif; ?>
        </h2>

        <p>
            داده‌ها برای بازه
            <strong><?php echo e($dashboard['period']['from']); ?></strong>
            تا
            <strong><?php echo e($dashboard['period']['to']); ?></strong>
            نمایش داده می‌شوند.
        </p>
    </div>

    <form
        method="GET"
        action="<?php echo e(route('management.dashboard')); ?>"
        class="dashboard-filter"
    >
        <div class="filter-heading">
            <?php echo $__env->make('management.partials.icon', ['name' => 'filter', 'size' => 18], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <span>فیلتر داشبورد</span>
        </div>

        <label>
            <span>محدوده</span>
            <select name="building_id">
                <?php if($platformAccess): ?>
                    <option value="">نمای کل پلتفرم</option>
                <?php endif; ?>

                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($building->id); ?>"
                        <?php if(
                            $selectedBuilding
                            && $selectedBuilding->id === $building->id
                        ): echo 'selected'; endif; ?>
                    >
                        <?php echo e($building->title); ?>

                        <?php if($building->complex): ?>
                            — <?php echo e($building->complex->title); ?>

                        <?php endif; ?>
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>

        <label>
            <span>از تاریخ</span>
            <input
                type="date"
                name="from"
                value="<?php echo e($dashboard['period']['from']); ?>"
            >
        </label>

        <label>
            <span>تا تاریخ</span>
            <input
                type="date"
                name="to"
                value="<?php echo e($dashboard['period']['to']); ?>"
            >
        </label>

        <button class="filter-submit" type="submit">
            اعمال فیلتر
        </button>
    </form>
</section>

<section
    class="role-workspace role-workspace--<?php echo e($roleProfile['tone'] ?? 'blue'); ?>"
    aria-label="فضای کاری نقش جاری"
>
    <div class="role-workspace__identity">
        <span class="role-workspace__icon">
            <?php echo $__env->make(
                'management.partials.icon',
                [
                    'name' => $roleProfile['icon'] ?? 'home',
                    'size' => 24,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </span>

        <div>
            <span class="eyebrow">
                فضای کاری شما
            </span>
            <h3>
                <?php echo e($roleProfile['short_title'] ?? $currentRole); ?>

            </h3>
            <p>
                <?php echo e($roleProfile['description'] ?? ''); ?>

            </p>
        </div>
    </div>

    <?php if($roleQuickActions): ?>
        <div class="role-workspace__actions">
            <?php $__currentLoopData = $roleQuickActions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                    class="role-quick-action"
                    href="<?php echo e(route(
                            'management.operations.show',
                            $action['resource']
                        )
                        . (
                            ($action['create'] ?? false)
                                ? '?create=1'
                                : ''
                        )); ?>"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => $action['icon'] ?? 'grid',
                            'size' => 17,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <span>
                        <?php echo e($action['title']); ?>

                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>

<section class="dashboard-glance-grid" aria-label="خلاصه حساب جاری">
    <article class="glance-card glance-card--wallet">
        <span class="glance-card__icon">
            <?php echo $__env->make('management.partials.icon', ['name' => 'wallet', 'size' => 20], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </span>
        <div>
            <span>کیف پول شخصی</span>
            <strong
                data-money-value="<?php echo e((int) ($headerWallet['available_balance'] ?? 0)); ?>"
            >
                <?php echo e(number_format((int) ($headerWallet['available_balance'] ?? 0))); ?>

            </strong>
            <small><?php echo e($headerWallet['currency'] ?? 'IRR'); ?> قابل استفاده</small>
        </div>
    </article>

    <article class="glance-card glance-card--notification">
        <span class="glance-card__icon">
            <?php echo $__env->make('management.partials.icon', ['name' => 'bell', 'size' => 20], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </span>
        <div>
            <span>اعلان‌های جدید</span>
            <strong>
                <?php echo e(number_format((int) ($headerNotifications['unread_count'] ?? 0))); ?>

            </strong>
            <small>پیام خوانده‌نشده</small>
        </div>
    </article>

    <article class="glance-card glance-card--role">
        <span class="glance-card__icon">
            <?php echo $__env->make('management.partials.icon', ['name' => 'shield', 'size' => 20], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </span>
        <div>
            <span>نقش فعال</span>
            <strong class="glance-card__text-value"><?php echo e($currentRole); ?></strong>
            <small><?php echo e($accessLabel); ?></small>
        </div>
    </article>

    <article class="glance-card glance-card--date">
        <span class="glance-card__icon">
            <?php echo $__env->make('management.partials.icon', ['name' => 'calendar', 'size' => 20], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </span>
        <div>
            <span>تاریخ امروز</span>
            <strong
                class="glance-card__text-value"
                data-jdate="<?php echo e(now()->toISOString()); ?>"
            >
                <?php echo e(now()->format('Y/m/d')); ?>

            </strong>
            <small>تقویم شمسی</small>
        </div>
    </article>
</section>

<?php if($errors->any()): ?>
    <div class="alert alert--danger dashboard-alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php if($dashboard['building_report_error'] || $dashboard['platform_report_error']): ?>
    <div class="alert alert--warning dashboard-alert">
        بخشی از داده‌های گزارش در این لحظه قابل دریافت نبود؛
        سایر شاخص‌های داشبورد بدون توقف نمایش داده شده‌اند.
    </div>
<?php endif; ?>

<section class="kpi-grid">
    <?php $__currentLoopData = $heroKpis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="kpi-card kpi-card--<?php echo e($item['tone']); ?>">
            <div class="kpi-card__icon">
                <?php echo $__env->make(
                    'management.partials.icon',
                    [
                        'name' => $item['icon'],
                        'size' => 24,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div class="kpi-card__content">
                <span><?php echo e($item['title']); ?></span>
                <strong><?php echo e($item['value']); ?></strong>
                <small><?php echo e($item['suffix']); ?></small>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php if($roleSections['modules'] ?? true): ?>
<section class="section-block" id="modules">
    <div class="section-heading">
        <div>
            <span class="eyebrow">System Capabilities</span>
            <h3>ماژول‌های سامانه</h3>
            <p>
                نمای یکپارچه امکانات پیاده‌سازی‌شده در هسته Buildino.
            </p>
        </div>

        <div class="section-heading__meta">
            <strong><?php echo e(count($roleModules)); ?></strong>
            <span>حوزه اصلی</span>
        </div>
    </div>

    <div class="module-grid">
        <?php $__currentLoopData = $roleModules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a
                class="module-card"
                href="<?php echo e(route(
                        'management.operations.show',
                        $module['target_resource']
                    )); ?>"
            >
                <div class="module-card__top">
                    <div class="module-icon">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => $module['icon'],
                                'size' => 22,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <span class="module-state">
                        فعال
                    </span>
                </div>

                <h4><?php echo e($module['title']); ?></h4>

                <p><?php echo e($module['description']); ?></p>

                <div class="module-card__footer">
                    <strong>
                        <?php if($module['money'] ?? false): ?>
                            <?php echo e($money($module['count'])); ?>

                        <?php else: ?>
                            <?php echo e(number_format((int) $module['count'])); ?>

                        <?php endif; ?>
                    </strong>
                    <span><?php echo e($module['unit']); ?></span>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>

<?php if(
    ($roleSections['finance'] ?? false)
    || ($roleSections['receivables'] ?? false)
): ?>
<section class="dashboard-grid dashboard-grid--2" id="financial">
    <?php if($roleSections['finance'] ?? false): ?>
    <article class="panel">
        <div class="panel__header">
            <div>
                <span class="eyebrow">Finance</span>
                <h3>
                    <?php echo e($selectedBuilding ? 'تصویر مالی ساختمان' : 'تصویر مالی پلتفرم'); ?>

                </h3>
            </div>

            <div class="panel-icon">
                <?php echo $__env->make('management.partials.icon', ['name' => 'wallet'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <?php if($buildingDashboard): ?>
            <?php
                $cashIn = (int) ($financialKpis['cash_inflow'] ?? 0);
                $cashOut = (int) ($financialKpis['cash_outflow'] ?? 0);
                $cashMax = max(1, $cashIn, $cashOut);
            ?>

            <div class="metric-list">
                <div class="metric-row">
                    <div class="metric-row__label">
                        <span>ورودی نقدی</span>
                        <strong><?php echo e($money($cashIn)); ?></strong>
                    </div>
                    <div class="progress-track">
                        <span
                            class="progress-bar progress-bar--success"
                            data-value="<?php echo e($cashIn); ?>"
                            data-max="<?php echo e($cashMax); ?>"
                        ></span>
                    </div>
                </div>

                <div class="metric-row">
                    <div class="metric-row__label">
                        <span>خروجی نقدی</span>
                        <strong><?php echo e($money($cashOut)); ?></strong>
                    </div>
                    <div class="progress-track">
                        <span
                            class="progress-bar progress-bar--warning"
                            data-value="<?php echo e($cashOut); ?>"
                            data-max="<?php echo e($cashMax); ?>"
                        ></span>
                    </div>
                </div>
            </div>

            <div class="mini-stat-grid">
                <div>
                    <span>خالص جریان نقد</span>
                    <strong>
                        <?php echo e($money($financialKpis['net_cash_flow'] ?? 0)); ?>

                    </strong>
                </div>
                <div>
                    <span>وصول شارژ</span>
                    <strong>
                        <?php echo e($money($financialKpis['charge_collections'] ?? 0)); ?>

                    </strong>
                </div>
                <div>
                    <span>درآمد Facility</span>
                    <strong>
                        <?php echo e($money($financialKpis['facility_paid_amount'] ?? 0)); ?>

                    </strong>
                </div>
                <div>
                    <span>GMV خدمات</span>
                    <strong>
                        <?php echo e($money($financialKpis['service_gmv'] ?? 0)); ?>

                    </strong>
                </div>
            </div>
        <?php elseif($platformSummary): ?>
            <div class="mini-stat-grid mini-stat-grid--platform">
                <div>
                    <span>GMV بازار خدمات</span>
                    <strong>
                        <?php echo e($money(
                            data_get(
                                $platformSummary,
                                'service_marketplace.gmv',
                                0
                            )
                        )); ?>

                    </strong>
                </div>
                <div>
                    <span>سهم ارائه‌دهندگان</span>
                    <strong>
                        <?php echo e($money(
                            data_get(
                                $platformSummary,
                                'service_marketplace.provider_amount',
                                0
                            )
                        )); ?>

                    </strong>
                </div>
                <div>
                    <span>تسویه Provider</span>
                    <strong>
                        <?php echo e($money(
                            data_get(
                                $platformSummary,
                                'provider_payouts.net_amount',
                                0
                            )
                        )); ?>

                    </strong>
                </div>
                <div>
                    <span>مغایرت Reconciliation</span>
                    <strong>
                        <?php echo e(number_format(
                            data_get(
                                $platformSummary,
                                'platform_wallets.reconciliation_mismatch_count',
                                0
                            )
                        )); ?>

                    </strong>
                </div>
            </div>
        <?php else: ?>
            <div class="empty-state">
                داده مالی برای این محدوده موجود نیست.
            </div>
        <?php endif; ?>
    </article>
    <?php endif; ?>

    <?php if($roleSections['receivables'] ?? false): ?>
    <article class="panel">
        <div class="panel__header">
            <div>
                <span class="eyebrow">Receivables</span>
                <h3>سن مطالبات</h3>
            </div>

            <div class="panel-icon">
                <?php echo $__env->make('management.partials.icon', ['name' => 'invoice'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <?php if($buildingDashboard && $aging): ?>
            <?php
                $agingLabels = [
                    'not_due' => 'سررسید نشده',
                    'days_1_30' => '۱ تا ۳۰ روز',
                    'days_31_60' => '۳۱ تا ۶۰ روز',
                    'days_61_90' => '۶۱ تا ۹۰ روز',
                    'days_90_plus' => 'بیش از ۹۰ روز',
                ];
            ?>

            <div class="aging-chart">
                <?php $__currentLoopData = $agingLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $value = (int) ($aging[$key] ?? 0);
                    ?>

                    <div class="aging-row">
                        <span class="aging-row__label"><?php echo e($label); ?></span>
                        <div class="aging-row__bar">
                            <span
                                class="progress-bar"
                                data-value="<?php echo e($value); ?>"
                                data-max="<?php echo e($agingMax); ?>"
                            ></span>
                        </div>
                        <strong><?php echo e($money($value)); ?></strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                Aging مطالبات پس از انتخاب یک ساختمان نمایش داده می‌شود.
            </div>
        <?php endif; ?>
    </article>
    <?php endif; ?>
</section>
<?php endif; ?>

<?php if($roleSections['operations'] ?? false): ?>
<section class="section-block" id="operations">
    <div class="section-heading">
        <div>
            <span class="eyebrow">Operations</span>
            <h3>وضعیت عملیات جاری</h3>
            <p>
                توزیع وضعیت رزروها، خدمات، پشتیبانی و صورتحساب‌ها.
            </p>
        </div>
    </div>

    <?php
        $operationDefinitions = collect([
            'reservations' => [
                'title' => 'رزرو امکانات',
                'icon' => 'calendar',
                'data' => $dashboard['operations']['reservations'],
            ],
            'services' => [
                'title' => 'خدمات ساختمانی',
                'icon' => 'tools',
                'data' => $dashboard['operations']['services'],
            ],
            'support' => [
                'title' => 'تیکت پشتیبانی',
                'icon' => 'support',
                'data' => $dashboard['operations']['support'],
            ],
            'invoices' => [
                'title' => 'صورتحساب‌ها',
                'icon' => 'invoice',
                'data' => $dashboard['operations']['invoices'],
            ],
        ])->only($roleOperationKeys);
    ?>

    <div class="operations-grid">
        <?php $__currentLoopData = $operationDefinitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="operation-card">
                <div class="operation-card__header">
                    <div class="operation-icon">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => $operation['icon'],
                                'size' => 20,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <h4><?php echo e($operation['title']); ?></h4>
                </div>

                <div class="status-list">
                    <?php $__empty_1 = true; $__currentLoopData = $operation['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if((int) $count > 0): ?>
                            <div class="status-list__item">
                                <span
                                    class="status-dot <?php echo e($statusClass($status)); ?>"
                                ></span>
                                <span>
                                    <?php echo e($statusLabels[$status] ?? $status); ?>

                                </span>
                                <strong><?php echo e(number_format($count)); ?></strong>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="empty-inline">داده‌ای ثبت نشده است.</div>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>

<?php if($roleSections['recent'] ?? false): ?>
<?php
    $managementDtQuery =
        array_filter(
            [
                'building_id' =>
                    $selectedBuilding
                        ?->getKey(),

                'from' =>
                    data_get(
                        $dashboard,
                        'period.from'
                    ),

                'to' =>
                    data_get(
                        $dashboard,
                        'period.to'
                    ),
            ],
            static fn ($value): bool =>
                $value !== null
                && $value !== ''
        );

    $managementDtUrl =
        static fn (
            string $table
        ): string =>
            route(
                'management.datatables',
                [
                    'table' =>
                        $table,
                ]
            )
            . (
                $managementDtQuery
                    ? '?'
                        . http_build_query(
                            $managementDtQuery
                        )
                    : ''
            );

    $managementRecentTables = [
        'payments' => [
            'title' =>
                'پرداخت‌های اخیر',
            'count_id' =>
                'management-payments-count',
            'columns' => [
                [
                    'data' =>
                        'payment_number',
                    'title' =>
                        'شماره',
                ],
                [
                    'data' =>
                        'payer_name',
                    'title' =>
                        'پرداخت‌کننده',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'amount_formatted',
                    'title' =>
                        'مبلغ',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'status_label',
                    'title' =>
                        'وضعیت',
                    'orderable' =>
                        false,
                    'status' =>
                        true,
                ],
                [
                    'data' =>
                        'created_at_jalali',
                    'title' =>
                        'زمان',
                    'orderable' =>
                        false,
                ],
            ],
        ],

        'reservations' => [
            'title' =>
                'رزروهای اخیر',
            'count_id' =>
                'management-reservations-count',
            'columns' => [
                [
                    'data' =>
                        'facility_title',
                    'title' =>
                        'امکان',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'user_name',
                    'title' =>
                        'کاربر',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'reservation_date_jalali',
                    'title' =>
                        'تاریخ',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'status_label',
                    'title' =>
                        'وضعیت',
                    'orderable' =>
                        false,
                    'status' =>
                        true,
                ],
            ],
        ],

        'services' => [
            'title' =>
                'درخواست‌های خدمت',
            'count_id' =>
                'management-services-count',
            'columns' => [
                [
                    'data' =>
                        'request_number',
                    'title' =>
                        'درخواست',
                ],
                [
                    'data' =>
                        'title',
                    'title' =>
                        'عنوان',
                ],
                [
                    'data' =>
                        'assigned_name',
                    'title' =>
                        'مسئول',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'status_label',
                    'title' =>
                        'وضعیت',
                    'orderable' =>
                        false,
                    'status' =>
                        true,
                ],
                [
                    'data' =>
                        'created_at_jalali',
                    'title' =>
                        'زمان',
                    'orderable' =>
                        false,
                ],
            ],
        ],

        'support' => [
            'title' =>
                'تیکت‌های اخیر',
            'count_id' =>
                'management-support-count',
            'columns' => [
                [
                    'data' =>
                        'ticket_number',
                    'title' =>
                        'تیکت',
                ],
                [
                    'data' =>
                        'subject',
                    'title' =>
                        'موضوع',
                ],
                [
                    'data' =>
                        'user_name',
                    'title' =>
                        'کاربر',
                    'orderable' =>
                        false,
                ],
                [
                    'data' =>
                        'status_label',
                    'title' =>
                        'وضعیت',
                    'orderable' =>
                        false,
                    'status' =>
                        true,
                ],
                [
                    'data' =>
                        'created_at_jalali',
                    'title' =>
                        'زمان',
                    'orderable' =>
                        false,
                ],
            ],
        ],
    ];
?>

<section class="section-block" id="recent">
    <div class="section-heading">
        <div>
            <span class="eyebrow">
                Server-side Activity
            </span>
            <h3>
                آخرین فعالیت‌ها
            </h3>
            <p>
                جستجو، مرتب‌سازی و صفحه‌بندی این جداول مستقیماً
                روی Query پایگاه داده انجام می‌شود.
            </p>
        </div>
    </div>

    <div class="dashboard-grid dashboard-grid--2">
        <?php $__currentLoopData = $roleRecentKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(
                ! isset(
                    $managementRecentTables[
                        $recentKey
                    ]
                )
            ) continue; ?>

            <?php
                $table =
                    $managementRecentTables[
                        $recentKey
                    ];
            ?>

            <article class="panel table-panel">
                <div class="panel__header panel__header--compact">
                    <h3>
                        <?php echo e($table['title']); ?>

                    </h3>

                    <span
                        class="record-count"
                        id="<?php echo e($table['count_id']); ?>"
                    >
                        —
                    </span>
                </div>

                <?php echo $__env->make(
                    'shared.server-datatable',
                    [
                        'id' =>
                            "management-{$recentKey}-table",

                        'url' =>
                            $managementDtUrl(
                                $recentKey
                            ),

                        'columns' =>
                            $table['columns'],

                        'pageLength' =>
                            10,

                        'countTarget' =>
                            '#'
                            . $table[
                                'count_id'
                            ],
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>

<?php if(
    ($roleSections['system'] ?? false)
    || ($roleSections['api'] ?? false)
): ?>
<section class="dashboard-grid dashboard-grid--2" id="system">
    <?php if($roleSections['system'] ?? false): ?>
    <article class="panel">
        <div class="panel__header">
            <div>
                <span class="eyebrow">System Health</span>
                <h3>سلامت سامانه</h3>
            </div>

            <span class="health-pill health-pill--<?php echo e($healthStatus); ?>">
                <span></span>
                <?php echo e(match($healthStatus) {
                    'ok' => 'سالم',
                    'degraded' => 'کاهش کیفیت',
                    'not_ready' => 'عدم آمادگی',
                    default => 'نامشخص',
                }); ?>

            </span>
        </div>

        <div class="health-summary">
            <div>
                <span>Readiness</span>
                <strong>
                    <?php echo e(($dashboard['health']['ready'] ?? false) ? 'Ready' : 'Not Ready'); ?>

                </strong>
            </div>

            <?php if(isset($dashboard['health']['checks'])): ?>
                <?php $__currentLoopData = [
                        'database' => 'Database',
                        'cache' => 'Cache',
                        'storage' => 'Storage',
                        'scheduler' => 'Scheduler',
                        'queues' => 'Queue',
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $check = $dashboard['health']['checks'][$key] ?? null;
                    ?>

                    <?php if($check): ?>
                        <div>
                            <span><?php echo e($label); ?></span>
                            <strong class="health-text health-text--<?php echo e($check['status'] ?? 'unknown'); ?>">
                                <?php echo e(strtoupper($check['status'] ?? 'unknown')); ?>

                            </strong>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div>
                    <span>سطح نمایش</span>
                    <strong>Readiness عمومی</strong>
                </div>
            <?php endif; ?>
        </div>
    </article>
    <?php endif; ?>

    <?php if($roleSections['api'] ?? false): ?>
    <article class="panel api-card">
        <div class="panel__header">
            <div>
                <span class="eyebrow">API Contract</span>
                <h3>وضعیت رابط برنامه‌نویسی</h3>
            </div>

            <div class="panel-icon">
                <?php echo $__env->make('management.partials.icon', ['name' => 'api'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <div class="api-stat-grid">
            <div>
                <span>نسخه</span>
                <strong>v<?php echo e($dashboard['api']['version']); ?></strong>
            </div>
            <div>
                <span>Path</span>
                <strong><?php echo e(number_format($dashboard['api']['paths'])); ?></strong>
            </div>
            <div>
                <span>Contract</span>
                <strong><?php echo e(number_format($dashboard['api']['contracts'])); ?></strong>
            </div>
            <div>
                <span>Protected</span>
                <strong><?php echo e(number_format($dashboard['api']['protected_paths'])); ?></strong>
            </div>
        </div>

        <p class="api-note">
            این داشبورد روی همان Domain Model، Service و Permissionهای Backend
            نهایی اجرا می‌شود؛ بنابراین داده نمایشی جداگانه یا Mock ندارد.
        </p>
    </article>
    <?php endif; ?>
</section>
<?php endif; ?>

<footer class="dashboard-footer">
    <div>
        Buildino Management Dashboard
        <span>•</span>
        Backend/API v<?php echo e($dashboard['api']['version']); ?>

    </div>

    <div>
        آخرین تولید داده:
        <?php echo e(\Carbon\Carbon::parse($dashboard['generated_at'])->format('Y-m-d H:i')); ?>

    </div>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('management.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/management/dashboard.blade.php ENDPATH**/ ?>