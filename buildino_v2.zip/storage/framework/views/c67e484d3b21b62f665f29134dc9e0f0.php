<!doctype html>
<html lang="fa" dir="rtl" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex,nofollow">
    <meta name="color-scheme" content="light dark">

    <title><?php echo $__env->yieldContent('title', 'پنل مدیریتی Buildino'); ?></title>

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-fonts.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.bootstrap.css')); ?>"
        integrity="<?php echo e(config('management_ui.libraries.bootstrap.css_integrity')); ?>"
        crossorigin="anonymous"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.sweetalert2.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.datatables.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(config('management_ui.libraries.datatables.responsive_css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-datatables.css')); ?>"
    >

    <link
        rel="stylesheet"
        href="<?php echo e(asset('css/buildino-management.css')); ?>"
    >

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<?php
    $ui = $managementUi ?? [];
    $nav = $ui['navigation'] ?? [];
    $header = $managementHeader ?? [];
    $personalWallet = $header['wallet'] ?? [];
    $headerNotifications =
        $header['notifications'] ?? [];
    $headerNotificationItems =
        $headerNotifications['items'] ?? [];
    $headerUnreadCount =
        (int) (
            $headerNotifications[
                'unread_count'
            ] ?? 0
        );
    $currentResource = request()->route('resource');

    $resourceActive = static function (
        array $resources
    ) use ($currentResource): bool {
        return in_array(
            $currentResource,
            $resources,
            true
        );
    };

    $visibleResources = collect(
        config('management_crud.resources', [])
    )
        ->filter(
            fn (
                array $resource,
                string $key
            ): bool =>
                in_array(
                    $key,
                    $ui['visible_resources'] ?? [],
                    true
                )
        );

    $structureTarget =
        collect([
            'complexes',
            'buildings',
            'blocks',
            'floors',
            'units',
        ])->first(
            fn (string $key): bool =>
                $visibleResources->has(
                    $key
                )
        );

    $quickCreate = collect([
        'complexes',
        'buildings',
        'users',
        'guest-visits',
        'reservations',
        'invoices',
        'service-requests',
        'support-tickets',
    ])->filter(
        fn (string $key): bool =>
            $visibleResources->has($key)
            && ! empty(
                $visibleResources[$key]['create']
                ?? null
            )
    );

    $commandResources =
        $visibleResources
            ->map(
                fn (
                    array $resource,
                    string $key
                ): array => [
                    'key' => $key,
                    'title' => $resource['title'],
                    'description' =>
                        $resource['description']
                        ?? '',
                    'group' =>
                        data_get(
                            config(
                                'management_crud.groups'
                            ),
                            ($resource['group'] ?? '')
                            . '.title',
                            'عملیات'
                        ),
                    'url' =>
                        route(
                            'management.operations.show',
                            $key
                        ),
                ]
            )
            ->values();
?>

<body class="management-body">
<div class="management-shell">
    <aside
        class="sidebar"
        id="managementSidebar"
        aria-label="منوی اصلی مدیریت"
    >
        <div class="sidebar__top">
            <a
                class="sidebar__brand"
                href="<?php echo e(route('management.dashboard')); ?>"
                aria-label="Buildino"
            >
                <div class="brand-mark">
                    <span>B</span>
                </div>

                <div class="brand-copy">
                    <strong>Buildino</strong>
                    <span>سامانه مدیریت هوشمند ساختمان</span>
                </div>
            </a>

            <button
                type="button"
                class="sidebar-collapse-button"
                id="sidebarCollapse"
                aria-label="جمع کردن منو"
                title="جمع کردن منو"
            >
                <?php echo $__env->make(
                    'management.partials.icon',
                    [
                        'name' => 'chevron',
                        'size' => 18,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </button>
        </div>

        <div class="sidebar__identity">
            <div class="avatar avatar--sidebar">
                <?php echo e(mb_substr(
                    $user->first_name
                        ?: $user->last_name
                        ?: 'U',
                    0,
                    1
                )); ?>

            </div>

            <div class="sidebar__identity-copy">
                <strong>
                    <?php echo e(trim(
                            ($user->first_name ?? '')
                            . ' '
                            . ($user->last_name ?? '')
                        )
                        ?: $user->mobile); ?>

                </strong>

                <span>
                    <?php echo e(data_get(
                            $ui,
                            'primary_role.display_name',
                            'کاربر سامانه'
                        )); ?>

                </span>
            </div>

            <span
                class="access-dot"
                title="<?php echo e($ui['access_label'] ?? 'دسترسی فعال'); ?>"
            ></span>
        </div>

        <div class="sidebar__scope">
            <?php echo $__env->make(
                'management.partials.icon',
                [
                    'name' => 'shield',
                    'size' => 15,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <span>
                <?php echo e($ui['access_label'] ?? 'دسترسی مدیریتی'); ?>

            </span>
        </div>

        <nav class="sidebar__nav">
            <section class="nav-group is-open" data-nav-group="general">
                <button
                    type="button"
                    class="nav-group__title"
                    data-nav-toggle
                >
                    <span>عمومی</span>
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'chevron',
                            'size' => 14,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>

                <div class="nav-group__items">
                    <a
                        href="<?php echo e(route('management.dashboard')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('management.dashboard')
                                ? 'is-active'
                                : ''); ?>"
                        data-nav-key="dashboard"
                    >
                        <span class="nav-link__icon">
                            <?php echo $__env->make(
                                'management.partials.icon',
                                ['name' => 'home']
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </span>

                        <span class="nav-link__label">
                            داشبورد
                        </span>
                    </a>

                    <?php if($nav['operations'] ?? false): ?>
                        <a
                            href="<?php echo e(route('management.operations.index')); ?>"
                            class="nav-link <?php echo e(request()->routeIs('management.operations.index')
                                    ? 'is-active'
                                    : ''); ?>"
                            data-nav-key="operations"
                        >
                            <span class="nav-link__icon">
                                <?php echo $__env->make(
                                    'management.partials.icon',
                                    ['name' => 'grid']
                                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </span>

                            <span class="nav-link__label">
                                مرکز عملیات
                            </span>
                        </a>
                    <?php endif; ?>
                </div>
            </section>

            <?php if(
                ($nav['structure'] ?? false)
                || ($nav['residents'] ?? false)
                || ($nav['guests'] ?? false)
                || ($nav['facilities'] ?? false)
            ): ?>
                <section
                    class="nav-group <?php echo e($resourceActive([
                            'complexes',
                            'buildings',
                            'blocks',
                            'floors',
                            'units',
                            'ownerships',
                            'occupancies',
                            'invitations',
                            'guest-visits',
                            'facilities',
                            'facility-schedules',
                            'facility-time-slots',
                            'facility-rules',
                            'facility-blackouts',
                            'reservations',
                        ])
                            ? 'is-open'
                            : ''); ?>"
                    data-nav-group="building"
                >
                    <button
                        type="button"
                        class="nav-group__title"
                        data-nav-toggle
                    >
                        <span>ساختمان و ساکنین</span>
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'chevron',
                                'size' => 14,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </button>

                    <div class="nav-group__items">
                        <?php if($nav['structure'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        $structureTarget
                                            ?? 'buildings'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'complexes',
                                        'buildings',
                                        'blocks',
                                        'floors',
                                        'units',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="structure"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'building']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    ساختار مجتمع
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['residents'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'occupancies'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'ownerships',
                                        'occupancies',
                                        'invitations',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="residents"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'users']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    مالکین و ساکنین
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['guests'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'guest-visits'
                                    )); ?>"
                                class="nav-link <?php echo e($currentResource === 'guest-visits'
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="guests"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'user-plus']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    مهمان و تردد
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['facilities'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'facilities'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'facilities',
                                        'facility-schedules',
                                        'facility-time-slots',
                                        'facility-rules',
                                        'facility-blackouts',
                                        'reservations',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="facilities"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'calendar']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    امکانات و رزرو
                                </span>
                            </a>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if(
                ($nav['finance'] ?? false)
                || ($nav['services'] ?? false)
                || ($nav['support'] ?? false)
            ): ?>
                <section
                    class="nav-group <?php echo e($resourceActive([
                            'charge-formulas',
                            'charge-periods',
                            'invoices',
                            'expenses',
                            'incomes',
                            'payments',
                            'bank-accounts',
                            'wallet-payouts',
                            'bill-payments',
                            'service-requests',
                            'support-tickets',
                            'support-categories',
                            'support-sla',
                        ])
                            ? 'is-open'
                            : ''); ?>"
                    data-nav-group="operations"
                >
                    <button
                        type="button"
                        class="nav-group__title"
                        data-nav-toggle
                    >
                        <span>عملیات سازمانی</span>
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'chevron',
                                'size' => 14,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </button>

                    <div class="nav-group__items">
                        <?php if($nav['finance'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'invoices'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'charge-formulas',
                                        'charge-periods',
                                        'invoices',
                                        'expenses',
                                        'incomes',
                                        'payments',
                                        'bank-accounts',
                                        'wallet-payouts',
                                        'bill-payments',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="finance"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'wallet']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    مالی و کیف پول
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['services'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'service-requests'
                                    )); ?>"
                                class="nav-link <?php echo e($currentResource === 'service-requests'
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="services"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'tools']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    خدمات ساختمان
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['support'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'support-tickets'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'support-tickets',
                                        'support-categories',
                                        'support-sla',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="support"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'support']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    پشتیبانی و SLA
                                </span>
                            </a>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if(
                ($nav['content'] ?? false)
                || ($nav['reports'] ?? false)
                || ($nav['access'] ?? false)
                || ($nav['system'] ?? false)
            ): ?>
                <section
                    class="nav-group <?php echo e($resourceActive([
                            'announcements',
                            'documents',
                            'meeting-minutes',
                            'notification-preferences',
                            'report-exports',
                            'users',
                            'roles',
                            'role-assignments',
                        ])
                            ? 'is-open'
                            : ''); ?>"
                    data-nav-group="administration"
                >
                    <button
                        type="button"
                        class="nav-group__title"
                        data-nav-toggle
                    >
                        <span>مدیریت سامانه</span>
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'chevron',
                                'size' => 14,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </button>

                    <div class="nav-group__items">
                        <?php if($nav['content'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'announcements'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'announcements',
                                        'documents',
                                        'meeting-minutes',
                                        'notification-preferences',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="content"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'bell']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    اطلاع‌رسانی و اسناد
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['reports'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'report-exports'
                                    )); ?>"
                                class="nav-link <?php echo e($currentResource === 'report-exports'
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="reports"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'chart']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    گزارش‌ها
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['access'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'users'
                                    )); ?>"
                                class="nav-link <?php echo e($resourceActive([
                                        'users',
                                        'roles',
                                        'role-assignments',
                                    ])
                                        ? 'is-active'
                                        : ''); ?>"
                                data-nav-key="access"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'key']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    کاربران و دسترسی
                                </span>
                            </a>
                        <?php endif; ?>

                        <?php if($nav['system'] ?? false): ?>
                            <a
                                href="<?php echo e(route(
                                        'management.dashboard'
                                    )); ?>#system"
                                class="nav-link"
                                data-nav-key="system"
                            >
                                <span class="nav-link__icon">
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        ['name' => 'health']
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </span>
                                <span class="nav-link__label">
                                    سلامت و کنترل
                                </span>
                            </a>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>
        </nav>

        <div class="sidebar__footer">
            <div class="sidebar__version">
                <span class="status-indicator"></span>
                <div>
                    <strong>Buildino v1.0</strong>
                    <span>سامانه آماده بهره‌برداری</span>
                </div>
            </div>
        </div>
    </aside>

    <button
        type="button"
        class="sidebar-backdrop"
        id="sidebarBackdrop"
        aria-label="بستن منو"
    ></button>

    <main class="main-area">
        <header class="topbar">
            <div class="topbar__start">
                <button
                    type="button"
                    class="icon-button mobile-menu"
                    id="sidebarToggle"
                    aria-label="نمایش منو"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        ['name' => 'menu']
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </button>

                <div class="page-heading">
                    <span class="page-heading__eyebrow">
                        BUILDINO MANAGEMENT
                    </span>

                    <h1>
                        <?php echo $__env->yieldContent(
                            'page-title',
                            'پنل مدیریتی'
                        ); ?>
                    </h1>

                    <p>
                        <?php echo $__env->yieldContent(
                            'page-subtitle',
                            'مدیریت و پایش سامانه Buildino'
                        ); ?>
                    </p>
                </div>
            </div>

            <div class="topbar__center">
                <button
                    type="button"
                    class="command-trigger"
                    id="commandTrigger"
                >
                    <?php echo $__env->make(
                        'management.partials.icon',
                        [
                            'name' => 'search',
                            'size' => 18,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <span>
                        جستجو در عملیات و فرم‌ها
                    </span>

                    <kbd>Ctrl K</kbd>
                </button>
            </div>

            <div class="topbar__actions">
                <div
                    class="topbar-menu"
                    data-popover
                >
                    <button
                        type="button"
                        class="wallet-summary-trigger"
                        data-popover-trigger
                        data-bs-toggle="tooltip"
                        data-bs-placement="bottom"
                        title="کیف پول شخصی"
                    >
                        <span class="wallet-summary-trigger__icon">
                            <?php echo $__env->make(
                                'management.partials.icon',
                                [
                                    'name' => 'wallet',
                                    'size' => 18,
                                ]
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </span>

                        <span class="wallet-summary-trigger__copy">
                            <small>موجودی قابل استفاده</small>
                            <strong
                                data-money-value="<?php echo e((int) (
                                        $personalWallet[
                                            'available_balance'
                                        ] ?? 0
                                    )); ?>"
                            >
                                <?php echo e(number_format(
                                        (int) (
                                            $personalWallet[
                                                'available_balance'
                                            ] ?? 0
                                        )
                                    )); ?>

                            </strong>
                        </span>

                        <span class="wallet-summary-trigger__currency">
                            <?php echo e($personalWallet['currency']
                                ?? 'IRR'); ?>

                        </span>
                    </button>

                    <div
                        class="popover-menu popover-menu--wallet"
                        data-popover-menu
                    >
                        <div class="wallet-popover__hero">
                            <span>
                                <?php echo $__env->make(
                                    'management.partials.icon',
                                    [
                                        'name' => 'wallet',
                                        'size' => 22,
                                    ]
                                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </span>

                            <div>
                                <small>
                                    کیف پول شخصی شما
                                </small>

                                <strong
                                    data-money-value="<?php echo e((int) (
                                            $personalWallet[
                                                'available_balance'
                                            ] ?? 0
                                        )); ?>"
                                >
                                    <?php echo e(number_format(
                                            (int) (
                                                $personalWallet[
                                                    'available_balance'
                                                ] ?? 0
                                            )
                                        )); ?>

                                </strong>

                                <em>
                                    <?php echo e($personalWallet[
                                            'currency'
                                        ] ?? 'IRR'); ?>

                                </em>
                            </div>
                        </div>

                        <div class="wallet-popover__stats">
                            <div>
                                <span>مانده کل</span>
                                <strong
                                    data-money-value="<?php echo e((int) (
                                            $personalWallet[
                                                'balance'
                                            ] ?? 0
                                        )); ?>"
                                >
                                    <?php echo e(number_format(
                                            (int) (
                                                $personalWallet[
                                                    'balance'
                                                ] ?? 0
                                            )
                                        )); ?>

                                </strong>
                            </div>

                            <div>
                                <span>مانده قفل‌شده</span>
                                <strong
                                    data-money-value="<?php echo e((int) (
                                            $personalWallet[
                                                'locked_balance'
                                            ] ?? 0
                                        )); ?>"
                                >
                                    <?php echo e(number_format(
                                            (int) (
                                                $personalWallet[
                                                    'locked_balance'
                                                ] ?? 0
                                            )
                                        )); ?>

                                </strong>
                            </div>
                        </div>

                        <?php if(! ($personalWallet['exists'] ?? false)): ?>
                            <div class="wallet-popover__note">
                                کیف پول شخصی برای این حساب هنوز Provision نشده است.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div
                    class="topbar-menu"
                    data-popover
                >
                    <button
                        type="button"
                        class="notification-trigger"
                        data-popover-trigger
                        aria-label="اعلان‌ها"
                        title="اعلان‌ها"
                    >
                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'bell',
                                'size' => 19,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <span
                            class="notification-trigger__badge"
                            id="managementNotificationBadge"
                            <?php if($headerUnreadCount < 1): ?>
                                hidden
                            <?php endif; ?>
                        >
                            <?php echo e($headerUnreadCount > 99
                                    ? '99+'
                                    : $headerUnreadCount); ?>

                        </span>
                    </button>

                    <div
                        class="popover-menu popover-menu--notifications"
                        data-popover-menu
                        id="managementNotificationMenu"
                    >
                        <div class="notification-menu__header">
                            <div>
                                <strong>اعلان‌ها</strong>
                                <span>
                                    <b id="managementNotificationUnreadText">
                                        <?php echo e(number_format(
                                                $headerUnreadCount
                                            )); ?>

                                    </b>
                                    خوانده‌نشده
                                </span>
                            </div>

                            <button
                                type="button"
                                id="managementNotificationsReadAll"
                                <?php if($headerUnreadCount < 1): echo 'disabled'; endif; ?>
                            >
                                خواندن همه
                            </button>
                        </div>

                        <div
                            class="notification-menu__list"
                            id="managementNotificationList"
                        >
                            <?php $__empty_1 = true; $__currentLoopData = $headerNotificationItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <button
                                    type="button"
                                    class="notification-item <?php echo e($notification['is_read']
                                            ? ''
                                            : 'is-unread'); ?>"
                                    data-management-notification
                                    data-notification-id="<?php echo e($notification['id']); ?>"
                                    <?php if($notification['href']): ?>
                                        data-notification-href="<?php echo e($notification['href']); ?>"
                                    <?php endif; ?>
                                >
                                    <span class="notification-item__marker"></span>

                                    <span class="notification-item__body">
                                        <strong>
                                            <?php echo e($notification[
                                                    'title'
                                                ]); ?>

                                        </strong>

                                        <span>
                                            <?php echo e(\Illuminate\Support\Str::limit(
                                                    $notification[
                                                        'message'
                                                    ],
                                                    115
                                                )); ?>

                                        </span>

                                        <small
                                            <?php if($notification['created_at']): ?>
                                                data-jdate="<?php echo e($notification[
                                                        'created_at'
                                                    ]); ?>"
                                            <?php endif; ?>
                                        >
                                            <?php echo e($notification[
                                                    'created_at_jalali'
                                                ]
                                                ?? '—'); ?>

                                        </small>
                                    </span>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div
                                    class="notification-menu__empty"
                                    id="managementNotificationEmpty"
                                >
                                    <?php echo $__env->make(
                                        'management.partials.icon',
                                        [
                                            'name' => 'bell',
                                            'size' => 26,
                                        ]
                                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                    <strong>
                                        اعلان جدیدی ندارید
                                    </strong>

                                    <span>
                                        پیام‌های سیستمی و عملیاتی اینجا نمایش داده می‌شوند.
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="notification-menu__footer">
                            <a
                                href="<?php echo e(route(
                                        'management.operations.show',
                                        'notification-preferences'
                                    )); ?>"
                            >
                                تنظیمات اعلان‌ها
                            </a>
                        </div>
                    </div>
                </div>

                <?php if($quickCreate->isNotEmpty()): ?>
                    <div class="topbar-menu" data-popover>
                        <button
                            type="button"
                            class="quick-create-button"
                            data-popover-trigger
                        >
                            <?php echo $__env->make(
                                'management.partials.icon',
                                [
                                    'name' => 'plus',
                                    'size' => 17,
                                ]
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <span>ثبت سریع</span>
                        </button>

                        <div
                            class="popover-menu popover-menu--quick"
                            data-popover-menu
                        >
                            <div class="popover-menu__heading">
                                ثبت رکورد جدید
                            </div>

                            <?php $__currentLoopData = $quickCreate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $item =
                                        $visibleResources[$key];
                                ?>

                                <a
                                    href="<?php echo e(route(
                                            'management.operations.show',
                                            $key
                                        )); ?>?create=1"
                                >
                                    <span>
                                        <?php echo e($item['title']); ?>

                                    </span>
                                    <small>
                                        <?php echo e($item['description'] ?? ''); ?>

                                    </small>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <button
                    type="button"
                    class="icon-button"
                    id="themeToggle"
                    aria-label="تغییر پوسته"
                    title="تغییر پوسته"
                >
                    <span class="theme-icon theme-icon--light">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            ['name' => 'moon']
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </span>

                    <span class="theme-icon theme-icon--dark">
                        <?php echo $__env->make(
                            'management.partials.icon',
                            ['name' => 'sun']
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </span>
                </button>

                <div class="topbar-menu" data-popover>
                    <button
                        type="button"
                        class="user-menu-trigger"
                        data-popover-trigger
                    >
                        <div class="avatar avatar--topbar">
                            <?php echo e(mb_substr(
                                $user->first_name
                                    ?: $user->last_name
                                    ?: 'U',
                                0,
                                1
                            )); ?>

                        </div>

                        <div class="user-menu-trigger__copy">
                            <strong>
                                <?php echo e(trim(
                                        ($user->first_name ?? '')
                                        . ' '
                                        . ($user->last_name ?? '')
                                    )
                                    ?: $user->mobile); ?>

                            </strong>

                            <span>
                                <?php echo e(data_get(
                                        $ui,
                                        'primary_role.display_name',
                                        'کاربر'
                                    )); ?>

                            </span>
                        </div>

                        <?php echo $__env->make(
                            'management.partials.icon',
                            [
                                'name' => 'chevron-down',
                                'size' => 14,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </button>

                    <div
                        class="popover-menu popover-menu--user"
                        data-popover-menu
                    >
                        <div class="user-popover__identity">
                            <div class="avatar avatar--popover">
                                <?php echo e(mb_substr(
                                    $user->first_name
                                        ?: $user->last_name
                                        ?: 'U',
                                    0,
                                    1
                                )); ?>

                            </div>

                            <div>
                                <strong>
                                    <?php echo e(trim(
                                            ($user->first_name ?? '')
                                            . ' '
                                            . ($user->last_name ?? '')
                                        )
                                        ?: $user->mobile); ?>

                                </strong>

                                <span dir="ltr">
                                    <?php echo e($user->mobile ?: $user->email); ?>

                                </span>
                            </div>
                        </div>

                        <div class="user-popover__meta">
                            <div>
                                <span>سطح دسترسی</span>
                                <strong>
                                    <?php echo e($ui['access_label'] ?? '—'); ?>

                                </strong>
                            </div>

                            <div>
                                <span>نقش اصلی</span>
                                <strong>
                                    <?php echo e(data_get(
                                            $ui,
                                            'primary_role.display_name',
                                            '—'
                                        )); ?>

                                </strong>
                            </div>
                        </div>

                        <?php if(! empty($ui['roles'])): ?>
                            <div class="role-chip-list">
                                <?php $__currentLoopData = $ui['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="role-chip">
                                        <strong>
                                            <?php echo e($role['display_name']); ?>

                                        </strong>
                                        <small>
                                            <?php echo e($role['scope_label']); ?>

                                        </small>
                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <form
                            method="POST"
                            action="<?php echo e(route('management.logout')); ?>"
                        >
                            <?php echo csrf_field(); ?>
                            <button
                                type="submit"
                                class="popover-logout"
                            >
                                <?php echo $__env->make(
                                    'management.partials.icon',
                                    [
                                        'name' => 'logout',
                                        'size' => 17,
                                    ]
                                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                خروج از حساب
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </header>

        <div class="page-content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>

<div
    class="command-backdrop"
    id="commandBackdrop"
></div>

<section
    class="command-palette"
    id="commandPalette"
    aria-hidden="true"
    aria-label="جستجوی عملیات"
>
    <div class="command-palette__search">
        <?php echo $__env->make(
            'management.partials.icon',
            [
                'name' => 'search',
                'size' => 20,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <input
            type="search"
            id="commandSearch"
            placeholder="مثلاً: مجتمع، کاربر، صورتحساب، رزرو..."
            autocomplete="off"
        >

        <button
            type="button"
            id="commandClose"
            aria-label="بستن"
        >
            ESC
        </button>
    </div>

    <div
        class="command-palette__results"
        id="commandResults"
    ></div>

    <div class="command-palette__footer">
        <span>
            ↑ ↓ انتخاب
        </span>
        <span>
            Enter ورود
        </span>
        <span>
            Esc بستن
        </span>
    </div>
</section>

<script>
    window.BuildinoManagementUi = {
        resources:
            <?php echo e(\Illuminate\Support\Js::from($commandResources)); ?>,
        accessLabel:
            <?php echo e(\Illuminate\Support\Js::from($ui['access_label'] ?? '')); ?>,
        role:
            <?php echo e(\Illuminate\Support\Js::from(
                data_get(
                    $ui,
                    'primary_role.display_name',
                    ''
                )
            )); ?>

    };
</script>

<script
    src="<?php echo e(config('management_ui.libraries.bootstrap.js')); ?>"
    integrity="<?php echo e(config('management_ui.libraries.bootstrap.js_integrity')); ?>"
    crossorigin="anonymous"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.bootstrap5_js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.responsive_js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.datatables.responsive_bootstrap5_js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.sweetalert2.js')); ?>"
    defer
></script>

<script
    src="<?php echo e(config('management_ui.libraries.jdate.js')); ?>"
    defer
></script>

<script
    src="<?php echo e(asset('js/buildino-datatables.js')); ?>"
    defer
></script>

<script
    src="<?php echo e(asset('js/buildino-management.js')); ?>"
    defer
></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\hosse\PhpstormProjects\buildino\resources\views/management/layouts/app.blade.php ENDPATH**/ ?>