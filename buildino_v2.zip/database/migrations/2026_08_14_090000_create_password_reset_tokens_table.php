<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (
            Schema::hasTable(
                'password_reset_tokens'
            )
        ) {
            return;
        }

        Schema::create(
            'password_reset_tokens',
            function (
                Blueprint $table
            ): void {
                $table
                    ->string('email')
                    ->primary();

                $table
                    ->string('token');

                $table
                    ->timestamp(
                        'created_at'
                    )
                    ->nullable();
            }
        );
    }

    public function down(): void
    {
        /*
         * Intentionally non-destructive.
         *
         * Some deployments may already provision Laravel's standard
         * password_reset_tokens table outside this application snapshot.
         * A rollback of this additive compatibility migration must not
         * remove shared password reset data.
         */
    }
};
