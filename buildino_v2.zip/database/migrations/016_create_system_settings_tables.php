<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('system_settings', function (Blueprint $table) {
            $table->id();
            $table->nullableMorphs('scope');
            $table->string('key');
            $table->longText('value')->nullable();
            $table->string('type', 30)->default('string');
            $table->string('group')->nullable()->index();
            $table->text('description')->nullable();
            $table->boolean('is_public')->default(false);
            $table->timestamps();
            $table->unique(['scope_type', 'scope_id', 'key'], 'system_setting_scope_key_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('system_settings');
    }
};
